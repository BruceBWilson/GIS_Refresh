﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSCorp.GIS_Refresh
{
    class GIS_CrossingRefresh
    {
        private int intRefreshPointer;
        private Int32 _isRunning = 0;
        private readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private GIS_CrossingData GIS_CrossingData = new GIS_CrossingData();

        public GIS_CrossingRefresh()
        {
            // Default constructor for this type
        }

        public Boolean IAmRunning { get { return _isRunning == 1; } }
        // Determines if the scheduler can execute this code.
        // We only want one scheduled job running at a time.

        public String Refresh()
        {
            // Invoked by the GIS Scheduled Job to pull data from GIS to update the Signal Crossings
            String strResult;

            _logger.Info("Beginning Refresh() Operation.");
            System.Threading.Interlocked.Increment(ref _isRunning);

            try
            {
                ProcessGISChangedDOTs();
                ReprocessGISExceptions();
            }
            catch (Exception err)
            {
                _logger.Error(err, "Refresh() Operation Fatal Error.");
                strResult = NotifyErrorOccurred(err.Message);
            }
            finally
            {
                System.Threading.Interlocked.Decrement(ref _isRunning);
            }

            _logger.Info("Ending Refresh() Operation.");

            return "Refreshed";
        }

        private String ProcessGISChangedDOTs()
        {
            // Pass DateTime to GIS web-service and process returned DOTs that have changed since.
            DateTime dtmGetLastRefreshed;
            DateTime dtmNow;
            String[] astrChangedDOTs;
            String strRequest_ID;
            String strResult;

            _logger.Info("Beginning ProcessGISChangedDOTs().");

            try
            {
                dtmGetLastRefreshed = GetLastRefreshed();
                _logger.Info("Last Refreshed: " + dtmGetLastRefreshed);

                dtmNow = System.DateTime.Now;
                astrChangedDOTs = GetChangedDOTs(dtmGetLastRefreshed);
                _logger.Info("Total Changed DOTs to process: " + astrChangedDOTs.Count());
                intRefreshPointer = 1;

                foreach (String strChangedDOT in astrChangedDOTs)
                {
                    strResult = GIS_CrossingRead(strChangedDOT);

                    if (strResult == "")
                    {
                        strRequest_ID = GetCrossingRequest_ID(strChangedDOT);

                        if (strRequest_ID == "")
                            strResult = CreateCrossing(strChangedDOT);
                        else
                            strResult = UpdateCrossingByDOT(strChangedDOT);
                    }

                    intRefreshPointer++;
                };

                // If all DOTs were processed without application error, set the Last Refreshed DateTime
                // to just before we started the Refresh operation
                strResult = UpdateLastRefreshed(dtmNow);
            }
            catch (Exception err)
            {
                _logger.Error(err, "ProcessGISChangedDOTs() Fatal Error.");
                throw;
            }

            _logger.Info("Ending ProcessGISChangedDOTs().");

            return "Refreshed";
        }

        private String ReprocessGISExceptions()
        {
            // Retrieve array of and process DOTs with exceptions marked for reprocessing.
            SHD_tblLocations_GIS_Error_WS.OutputMapping5GetListValues[] astrReprocessDOTs;
            String strRequest_ID;
            String strResult;
            String strDOT;

            _logger.Info("Beginning ReprocessGISExceptions().");

            try
            {
                astrReprocessDOTs = GetReprocessDOTs();
                _logger.Info("Total Changed DOTs to reprocess: " + astrReprocessDOTs.Count());
                intRefreshPointer = 1;

                foreach (var varReprocessDOT in astrReprocessDOTs)
                {
                    strDOT = varReprocessDOT.AARDOTNumber;
                    strResult = GIS_CrossingRead(strDOT);

                    if (strResult == "")
                    {
                        strRequest_ID = GetCrossingRequest_ID(strDOT);

                        if (strRequest_ID == "")
                            strResult = CreateCrossing(strDOT);
                        else
                            strResult = UpdateCrossingByDOT(strDOT);

                        if (strResult == "")
                            ClearGISException(strDOT);
                    }

                    intRefreshPointer++;
                };

            }
            catch (Exception err)
            {
                _logger.Error(err, "ReprocessGISExceptions() Fatal Error.");
                throw;
            }

            _logger.Info("Ending ReprocessGISExceptions().");

            return "Refreshed";
        }

        private String NotifyErrorOccurred(String strErrorMessage)
        {
            // Record fatal application error in SHD_tblLocations_GIS_Refresh form.
            // Remedy workflow on this form sends an email to the Remedy Administrator.
            String strResult;

            try
            {
                using (SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient client = new SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient("GIS_RefreshSoap"))
                {
                    strResult = client.NotifyErrorOccurred(new SHD_tblLocations_GIS_Refresh_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    "000000000000001",
                    SHD_tblLocations_GIS_Refresh_WS.SET_NotifyErrorOccurredType.Now,
                    strErrorMessage);
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "NotifyErrorOccurred() Fatal Error.");
                strResult = "Failure";
                throw;
            }

            return strResult;
        }

        private String NotifyCrossingErrorOccurred(String strDOT, String strErrorMessage)
        {
            // Record Crossing processing error in SHD_tblLocations_GIS_Error form.
            // Remedy workflow on this form sends an email to the Remedy Administrator and GIS Crossing Data team.
            String strResult;
            String strRequest_ID;

            try
            {
                // If DOT has not had error previously reported, create error record, OW update existing.
                strRequest_ID = GetGISException(strDOT);

                if (strRequest_ID == "")
                    strResult = CreateGISException(strDOT, strErrorMessage);
                else
                    strResult = UpdateGISException(strRequest_ID, strErrorMessage);

                // Todo: Call the GIS Error Reporting web-service when it is available to add an entry into their Exception queue.
            }
            catch (Exception err)
            {
                _logger.Error(err, "NotifyCrossingErrorOccurred() Fatal Error.");
                strResult = "Failure";
                throw;
            }

            return strResult;
        }

        private String GetGISException(String strDOT)
        {
            // Lookup GIS Exception record by DOT Number
            String strRequest_ID;

            try
            {
                using (SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient client = new SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient("GIS_ErrorSoap"))
                {
                    strRequest_ID = client.GetErrorByDOT(new SHD_tblLocations_GIS_Error_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                        strDOT);
                }
            }
            catch (Exception err)
            {
                // If the record is not on file, Remedy throws an error.
                // We need to continue processing and add the new record from the calling process.
                _logger.Error(err, "GetGISException() Fatal Error.");
                strRequest_ID = "";
            }

            return strRequest_ID;
        }

        private String CreateGISException(String strDOT, String strErrorMessage)
        {
            // Create error record for passed DOT.
            String strResult;

            try
            {
                using (SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient client = new SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient("GIS_ErrorSoap"))
                {
                    strResult = client.CreateError(new SHD_tblLocations_GIS_Error_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strErrorMessage,
                    strDOT);
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "CreateGISException() Fatal Error.");
                throw;
            }

            return strResult;
        }

        private String UpdateGISException(String strRequest_ID, String strErrorMessage)
        {
            // Update existing error record for passed DOT.
            String strResult;

            try
            {
                using (SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient client = new SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient("GIS_ErrorSoap"))
                {
                    strResult = client.UpdateError(new SHD_tblLocations_GIS_Error_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    SHD_tblLocations_GIS_Error_WS.StatusType.Pending,
                    strErrorMessage,
                    System.DateTime.Now,
                    null,   // Reprocess_Crossing
                    strRequest_ID);
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "UpdateGISException() Fatal Error.");
                throw;
            }

            return strResult;
        }

        private String ClearGISException(String strDOT)
        {
            // Clear previously recorded error for passed DOT.
            DateTime dtmNow = dtmNow = System.DateTime.Now;
            String strRequest_ID;

            try
            {
                using (SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient client = new SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient("GIS_ErrorSoap"))
                {
                    strRequest_ID = client.ClearGISException(new SHD_tblLocations_GIS_Error_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strDOT,
                    dtmNow,
                    dtmNow,
                    null,   // Reprocess_Crossing
                    SHD_tblLocations_GIS_Error_WS.StatusType.Resolved);
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "ClearGISException() Fatal Error.");
                throw;
            }

            return "";
        }

        private DateTime GetLastRefreshed()
        {
            // Read and return Last Refreshed Date/Time from SHD_tblLocations_GIS_Refresh form.
            DateTime dtmGetLastRefreshed;

            try
            {
                using (SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient client = new SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient("GIS_RefreshSoap"))
                {
                    DateTime? a = client.GetLastRefreshed(new SHD_tblLocations_GIS_Refresh_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    "000000000000001");

                    dtmGetLastRefreshed = a.Value;
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "GetLastRefreshed() Fatal Error.");
                throw;
            }

            return dtmGetLastRefreshed;
        }

        private String[] GetChangedDOTs(DateTime dtmGetLastRefreshed)
        {
            // Query GIS for and return list of Changed DOTs since passed Date/Time.
            String[] astrChangedDOTs;
            String strGetLastRefreshed = dtmGetLastRefreshed.ToString("yyyy-MM-dd.HH.mm.ss");

            _logger.Info("Retrieving Changed DOTs for: " + strGetLastRefreshed);

            try
            {
                using (GIS_xrec.IxrecClient client = new GIS_xrec.IxrecClient("BasicHttpBinding_Ixrec"))
                {
                    astrChangedDOTs = client.GetChangedDOTs(strGetLastRefreshed);
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "GetChangedDOTs() Fatal Error.");
                throw;
            }

            return astrChangedDOTs;
        }

        private SHD_tblLocations_GIS_Error_WS.OutputMapping5GetListValues[] GetReprocessDOTs()
        {
            // Return list of GIS Exceptions flagged to reprocess.
            // NOTE: SHD_tblLocations_GIS_Error_Reprocess escalation sets all Pending records to Reprocess.
            SHD_tblLocations_GIS_Error_WS.OutputMapping5GetListValues[] astrReprocessDOTs;
            String strQualification = "'Reprocess_Crossing' = \"Yes\"";

            try
            {
                using (SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient client = new SHD_tblLocations_GIS_Error_WS.GIS_ErrorPortTypeClient("GIS_ErrorSoap"))
                {
                    astrReprocessDOTs = client.GetErrorList(new SHD_tblLocations_GIS_Error_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strQualification, "0", "10000");
                }
                _logger.Info("GetReprocessDOTS() returned " + astrReprocessDOTs.Count().ToString() + " DOTs to reprocess.");
            }
            catch (Exception err)
            {
                _logger.Error(err, "GetReprocessDOTs() Fatal Error.");

                if (err.Message.ToString() == "ERROR (302): Entry does not exist in database; For qualification:'Reprocess_Crossing' = \"Yes\"")
                    astrReprocessDOTs = new SHD_tblLocations_GIS_Error_WS.OutputMapping5GetListValues[0];
                else
                    throw;
            }

            return astrReprocessDOTs;
        }

        private String GetCrossingRequest_ID(String strChangedDOT)
        {
            // Search Remedy SHD_tblLocations form for passed DOT and return its Request ID.
            // If not found, return empty string.
            String strRequest_ID;

            try
            {
                using (SHD_tblLocations_GIS_WS.GISPortTypeClient client = new SHD_tblLocations_GIS_WS.GISPortTypeClient("GISSoap"))
                {
                    strRequest_ID = client.GetCrossingRequest_ID(new SHD_tblLocations_GIS_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strChangedDOT);
                }
            }
            catch (Exception err)
            {
                // If the record is not on file, Remedy throws an error.
                // We need to continue processing and add the new record from the calling process.
                _logger.Error(err, "GetCrossingRequest_ID() Fatal Error.");
                strRequest_ID = "";
            }

            return strRequest_ID;
        }

        private int? ToIntNull(String strNumber)
        {
            // Return passed numeric string value as integer.
            int? intReturn;

            if (strNumber == null)
                intReturn = null;
            else if (strNumber == "")
                intReturn = null;
            else
                intReturn = Convert.ToInt32(strNumber);

            return intReturn;
        }

        private SHD_tblLocations_GIS_WS.Public_Access_CodeType? ToYesNo(String strYesNo)
        {
            // Return passed 1-Based Yes/No string value as enumerated value.
            SHD_tblLocations_GIS_WS.Public_Access_CodeType? intReturn;

            switch (strYesNo)
            {
                case "1":
                    intReturn = SHD_tblLocations_GIS_WS.Public_Access_CodeType.Yes;
                    break;
                case "2":
                    intReturn = SHD_tblLocations_GIS_WS.Public_Access_CodeType.No;
                    break;
                default:
                    intReturn = null;
                    break;
            }

            return intReturn;
        }

        private String LocationType()
        {
            // Look at combinations demographic and Traffic Control Device fields; auto-calculate and return Location Type.
            String strLocationType;
            bool blnHasFlashers;

            // Determine if site has Flashers
            if (GIS_CrossingData.intTCD2_FlashNov > 0       // Not Over Traffic Lane Count
                | GIS_CrossingData.intTCD2_FlashOv > 0      // Over Traffic Lane Count
                | GIS_CrossingData.intTCD2_FlashPost > 0    // Mast Mounted Flashing Lights Count
                | GIS_CrossingData.intTCD2_FlashPai > 0)    // Total Count of Flashing Light Pairs
                blnHasFlashers = true;
            else
                blnHasFlashers = false;

            // A Crossing must have both Gates and Flashers to be FLGS: Pedestrian FLGS:
            if (GIS_CrossingData.intCrossing_Type_Code == SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Pedestrian
                & GIS_CrossingData.intTCD2_Gates > 0
                & blnHasFlashers == true)
                strLocationType = "PEDESTRIAN FLGS";

            // A Crossing must have both Gates and Flashers to be FLGS: Non-Pedestrian FLGS:
            else if (GIS_CrossingData.intTCD2_Gates > 0
                & blnHasFlashers == true)
                strLocationType = "FLGS";

            // No Gates present, only Flashers to be FLS: Pedestrian FLS:
            else if (GIS_CrossingData.intCrossing_Type_Code == SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Pedestrian
                & blnHasFlashers == true)
                strLocationType = "PEDESTRIAN FLS";

            // No Gates present, only Flashers to be FLS: Non-Pedestrian FLS:
            else if (blnHasFlashers == true)
                strLocationType = "FLS";

            else if (GIS_CrossingData.intTCD2_XBuck > 0 & GIS_CrossingData.intTCD2_StopStd > 0)
                strLocationType = "CROSSBUCKS  & STOP SIGNS";

            else if (GIS_CrossingData.intTCD2_XBuck > 0)
                strLocationType = "CROSSBUCKS";

            else if (GIS_CrossingData.intTCD2_StopStd > 0)
                strLocationType = "STOP SIGNS";

            else if (GIS_CrossingData.intCrossing_Type_Code == SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Pedestrian & GIS_CrossingData.intTCD2_Bells > 0)
                strLocationType = "PEDESTRIAN BELL";

            else if (GIS_CrossingData.intTCD2_Bells > 0)
                strLocationType = "BELL";

            else if (GIS_CrossingData.intCrossing_Position_Code == SHD_tblLocations_GIS_WS.Crossing_Position_CodeType.RROver)
                strLocationType = "OVERPASS";

            else if (GIS_CrossingData.intCrossing_Position_Code == SHD_tblLocations_GIS_WS.Crossing_Position_CodeType.RRUnder)
                strLocationType = "UNDERPASS";

            else if (GIS_CrossingData.intCrossing_Type_Code == SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Pedestrian)
                strLocationType = "PEDESTRIAN";

            else
                strLocationType = "NONE";

            return strLocationType;
        }

        private String GIS_CrossingRead(String strChangedDOT)
        {
            // Query GIS web-service for passed DOT.  Read all values and assign them to global GIS Crossing Data object.
            String strResult;
            String strErrMessage;

            try
            {
                _logger.Info("  Reading:  " + strChangedDOT);

                // Get Crossing data from GIS GetXingByDOT Method
                using (GIS_xrec.IxrecClient client = new GIS_xrec.IxrecClient("BasicHttpBinding_Ixrec"))
                {
                    GIS_xrec.XingInfo Xing = client.GetXingByDOT(strChangedDOT);

                    // Required field assignments:
                    GIS_CrossingData.strCity = Xing.LC.IN_CITY;
                    GIS_CrossingData.strDivision = Xing.OR.RRDIV;
                    GIS_CrossingData.strDivCode = Xing.OR.DIVCODE;

                    if (GIS_CrossingData.strDivCode == null)
                        GIS_CrossingData.strLineID = "N/A";
                    else
                        GIS_CrossingData.strLineID = Xing.OR.PRFXMILEPOST.Trim().PadLeft(2, '_') + GIS_CrossingData.strDivCode + Xing.OR.SFXMILEPOST.Trim().PadRight(2, '_');

                    GIS_CrossingData.strLocationCategory = "Crossing";
                    GIS_CrossingData.strMP = Xing.OR.MILEPOST.ToString("0000.000");
                    GIS_CrossingData.strOperationsDivision = Xing.OR.RRDIV;

                    switch (Xing.OR.SGNLEQP)
                    {                               // Is Track Signaled?
                        case "1":                   // Yes
                            GIS_CrossingData.intPriority = SHD_tblLocations_GIS_WS.PriorityType.High;
                            break;
                        case "2":                   // No
                            GIS_CrossingData.intPriority = SHD_tblLocations_GIS_WS.PriorityType.Low;
                            break;
                        default:
                            GIS_CrossingData.intPriority = SHD_tblLocations_GIS_WS.PriorityType.High;
                            break;
                    }

                    GIS_CrossingData.strShort_Description = "Created from crossing data via GIS web-service";
                    if (Xing.LC.STREET.Trim() != "") GIS_CrossingData.strSiteName = Xing.LC.STREET; else GIS_CrossingData.strSiteName = "N/A";
                    GIS_CrossingData.strState = Xing.LC.STATE_NAME;
                    GIS_CrossingData.intStatus = SHD_tblLocations_GIS_WS.StatusType.Active;
                    GIS_CrossingData.strTerritoryCode = "AAAAA";     // Territory Code is not provided by GIS

                    // Optional field assignments:
                    GIS_CrossingData.strStreet = Xing.LC.STREET;
                    GIS_CrossingData.strPrefix = Xing.OR.PRFXMILEPOST;
                    GIS_CrossingData.strSuffix = Xing.OR.SFXMILEPOST;
                    GIS_CrossingData.strCounty = Xing.LC.COUNTY_NAME;
                    GIS_CrossingData.strBranch = Xing.OR.BRANCH;
                    GIS_CrossingData.strCrossing_District = Xing.OR.RRSUBDIV;

                    switch (Xing.LC.NEAREST.ToString())
                    {
                        case "0":                   // In
                            GIS_CrossingData.strCity_Limits = "Y";
                            break;
                        case "1":                   // Near
                            GIS_CrossingData.strCity_Limits = "N";
                            break;
                        default:
                            GIS_CrossingData.strCity_Limits = "";
                            break;
                    }

                    GIS_CrossingData.strRoute_No = Xing.LC.HIGHWAY;
                    GIS_CrossingData.strRailroad_Code = Xing.LC.RAILROAD;
                    GIS_CrossingData.strLatitude = Xing.LC.LATITUDE.ToString("00.0000000");
                    GIS_CrossingData.strLongitude = Xing.LC.LONGITUDE.ToString("00.0000000");
                    GIS_CrossingData.strCenterLineCrossingLatitude = Xing.LC.LATITUDE.ToString("00.0000000");
                    GIS_CrossingData.strCenterLineCrossingLongitude = Xing.LC.LONGITUDE.ToString("00.0000000");

                    switch (Xing.LC.POSXING.ToString())
                    {
                        case "1":
                            GIS_CrossingData.intCrossing_Position_Code = SHD_tblLocations_GIS_WS.Crossing_Position_CodeType.AtGrade;
                            break;
                        case "2":
                            GIS_CrossingData.intCrossing_Position_Code = SHD_tblLocations_GIS_WS.Crossing_Position_CodeType.RRUnder;
                            break;
                        case "3":
                            GIS_CrossingData.intCrossing_Position_Code = SHD_tblLocations_GIS_WS.Crossing_Position_CodeType.RROver;
                            break;
                        default:
                            GIS_CrossingData.intCrossing_Position_Code = null;
                            break;
                    }

                    switch (Xing.LC.TYPEXING.ToString())
                    {
                        case "2":
                            GIS_CrossingData.intCrossing_Type_Code = SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Private;
                            break;
                        case "3":
                            GIS_CrossingData.intCrossing_Type_Code = SHD_tblLocations_GIS_WS.Crossing_Type_CodeType.Public;
                            break;
                        default:
                            GIS_CrossingData.intCrossing_Type_Code = null;
                            break;
                    }

                    GIS_CrossingData.strBlock_Number = Xing.LC.BLOCKNMB;

                    switch (Xing.LC.WHISTBAN.ToString())
                    {
                        case "0":
                            GIS_CrossingData.strQuiet_Zone = "No";
                            break;
                        case "1":
                            GIS_CrossingData.strQuiet_Zone = "24 Hr";
                            break;
                        case "2":
                            GIS_CrossingData.strQuiet_Zone = "Partial";
                            break;
                        case "3":
                            GIS_CrossingData.strQuiet_Zone = "Chicago Excused";
                            break;
                        default:
                            GIS_CrossingData.strQuiet_Zone = null;
                            break;
                    }

                    if (Xing.LC.RRCONT == "") GIS_CrossingData.strSite_Phone = ""; else GIS_CrossingData.strSite_Phone = Xing.LC.RRCONT.Insert(6, "-").Insert(3, "-");
                    if (Xing.LC.HWYCONT == "") GIS_CrossingData.strState_Contact_Phone = ""; else GIS_CrossingData.strState_Contact_Phone = Xing.LC.HWYCONT.Insert(6, "-").Insert(3, "-");

                    GIS_CrossingData.strEmergency_Notification_Phone = Xing.LC.POLCONT.Insert(6, "-").Insert(3, "-");
                    GIS_CrossingData.strStation = Xing.LC.TTSTNNAM;

                    switch (Xing.LC.DEVELTYPID)
                    {
                        case "11":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.OpenSpace;
                            break;
                        case "12":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Residential;
                            break;
                        case "13":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Commercial;
                            break;
                        case "14":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Industrial;
                            break;
                        case "15":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Institutional;
                            break;
                        case "16":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Farm;
                            break;
                        case "17":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.Recreational;
                            break;
                        case "18":
                            GIS_CrossingData.intPrivate_Crossing_Code = SHD_tblLocations_GIS_WS.Private_Crossing_CodeType.RRYard;
                            break;
                        default:
                            GIS_CrossingData.intPrivate_Crossing_Code = null;
                            break;
                    }

                    GIS_CrossingData.strLineSegment = Xing.LC.RRID;

                    switch (Xing.LC.XPURPOSE.ToString())
                    {
                        case "1":
                            GIS_CrossingData.intCrossing_Purpose_Code = SHD_tblLocations_GIS_WS.Crossing_Purpose_CodeType.Highway;
                            break;
                        case "2":
                            GIS_CrossingData.intCrossing_Purpose_Code = SHD_tblLocations_GIS_WS.Crossing_Purpose_CodeType.PathwayPedestrian;
                            break;
                        case "3":
                            GIS_CrossingData.intCrossing_Purpose_Code = SHD_tblLocations_GIS_WS.Crossing_Purpose_CodeType.StationPedestrian;
                            break;
                        default:
                            GIS_CrossingData.intCrossing_Purpose_Code = null;
                            break;
                    }

                    GIS_CrossingData.strCrossing_Owner = Xing.LC.XINGOWNR;
                    GIS_CrossingData.intPublic_Access_Code = ToYesNo(Xing.LC.OPENPUB.ToString());
                    GIS_CrossingData.intMainTrk = ToIntNull(Xing.OR.MAINTRK);
                    GIS_CrossingData.intSidingTrk = ToIntNull(Xing.OR.SIDINGTRK);
                    GIS_CrossingData.intYardTrk = ToIntNull(Xing.OR.YARDTRK);
                    GIS_CrossingData.intTransitTrk = ToIntNull(Xing.OR.TRANSITTRK);
                    GIS_CrossingData.intIndustryTrk = ToIntNull(Xing.OR.INDUSTRYTRK);
                    GIS_CrossingData.strParent_RR = Xing.LC.RRMAIN;

                    if (Xing.XQ.LAST_FRA_SUBMISSION == null)
                        GIS_CrossingData.dtmPostmarkDate = null;
                    else
                        GIS_CrossingData.dtmPostmarkDate = Convert.ToDateTime(Xing.XQ.LAST_FRA_SUBMISSION);

                    switch (Xing.RB.REASONID.ToString())
                    {
                        case "14":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.ChangeinData;
                            break;
                        case "15":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.NewCrossing;
                            break;
                        case "16":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.Closed;
                            break;
                        case "19":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.ReOpen;
                            break;
                        case "20":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.DateChangeOnly;
                            break;
                        case "21":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.ChangeinPrimaryOperatingRR;
                            break;
                        case "22":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.AdminCorrection;
                            break;
                        case "23":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.QuietZoneUpdate;
                            break;
                        case "24":
                            GIS_CrossingData.intReasonID = SHD_tblLocations_GIS_WS.ReasonIDType.NoTrainTraffic;
                            break;
                        default:
                            GIS_CrossingData.intReasonID = null;
                            break;
                    }

                    if (Xing.LC.WHISTDATE != "")
                        GIS_CrossingData.Quiet_Zone_Date_Established = Convert.ToDateTime(Xing.LC.WHISTDATE);
                    else
                        GIS_CrossingData.Quiet_Zone_Date_Established = null;

                    // Foreign Railroad field assignments:
                    GIS_CrossingData.intSameInd = ToYesNo(Xing.LC.SAMEIND.ToString());
                    if (Xing.LC.SEPRR1 == "-1") GIS_CrossingData.strSepRr1 = ""; else GIS_CrossingData.strSepRr1 = Xing.LC.SEPRR1;
                    if (Xing.LC.SEPRR2 == "-1") GIS_CrossingData.strSepRr2 = ""; else GIS_CrossingData.strSepRr2 = Xing.LC.SEPRR2;

                    GIS_CrossingData.intSepInd = ToYesNo(Xing.LC.SEPIND.ToString());
                    if (Xing.LC.SAMERR1 == "-1") GIS_CrossingData.strSameRr1 = ""; else GIS_CrossingData.strSameRr1 = Xing.LC.SAMERR1;
                    if (Xing.LC.SAMERR2 == "-1") GIS_CrossingData.strSameRr2 = ""; else GIS_CrossingData.strSameRr2 = Xing.LC.SAMERR2;

                    // Passive Traffic Control Device field assignments:
                    GIS_CrossingData.intTCD2_NoSigns = ToYesNo(Xing.HD.NOSIGNS.ToString());
                    GIS_CrossingData.intTCD2_XBuck = ToIntNull(Xing.HD.XBUCK);
                    GIS_CrossingData.intTCD2_StopStd = ToIntNull(Xing.HD.STOPSTD);
                    GIS_CrossingData.intTCD2_YieldStd = ToIntNull(Xing.HD.YIELDSTD);
                    GIS_CrossingData.intTCD2_AdvW10_1 = ToIntNull(Xing.HD.ADVW10_1);
                    GIS_CrossingData.intTCD2_AdvW10_2 = ToIntNull(Xing.HD.ADVW10_2);
                    GIS_CrossingData.intTCD2_AdvW10_3 = ToIntNull(Xing.HD.ADVW10_3);
                    GIS_CrossingData.intTCD2_AdvW10_4 = ToIntNull(Xing.HD.ADVW10_4);
                    GIS_CrossingData.intTCD2_AdvW10_11 = ToIntNull(Xing.HD.ADVW10_11);
                    GIS_CrossingData.intTCD2_AdvW10_12 = ToIntNull(Xing.HD.ADVW10_12);
                    GIS_CrossingData.intTCD2_Low_GrndSigns = ToIntNull(Xing.HD.LOW_GRNDSIGNS);

                    if (Xing.HD.PAVEMRKIDS.Contains("1")) GIS_CrossingData.intTCD2_PaveMrkIDs_Stop_Lines = 0; else GIS_CrossingData.intTCD2_PaveMrkIDs_Stop_Lines = null;
                    if (Xing.HD.PAVEMRKIDS.Contains("2")) GIS_CrossingData.intTCD2_PaveMrkIDs_RR_Xing_Symbols = 0; else GIS_CrossingData.intTCD2_PaveMrkIDs_RR_Xing_Symbols = null;
                    if (Xing.HD.PAVEMRKIDS.Contains("3")) GIS_CrossingData.intTCD2_PaveMrkIDs_Dynamic_Envelope = 0; else GIS_CrossingData.intTCD2_PaveMrkIDs_Dynamic_Envelope = null;
                    if (Xing.HD.PAVEMRKIDS.Contains("0")) GIS_CrossingData.intTCD2_PaveMrkIDs_None = 0; else GIS_CrossingData.intTCD2_PaveMrkIDs_None = null;

                    switch (Xing.HD.CHANNEL.ToString())
                    {
                        case "1":
                            GIS_CrossingData.intTCD2_Channel = SHD_tblLocations_GIS_WS.TCD2_ChannelType.AllApproaches;
                            break;
                        case "2":
                            GIS_CrossingData.intTCD2_Channel = SHD_tblLocations_GIS_WS.TCD2_ChannelType.OneApproach;
                            break;
                        case "3":
                            GIS_CrossingData.intTCD2_Channel = SHD_tblLocations_GIS_WS.TCD2_ChannelType.MedianAllApproaches;
                            break;
                        case "4":
                            GIS_CrossingData.intTCD2_Channel = SHD_tblLocations_GIS_WS.TCD2_ChannelType.MedianOneApproach;
                            break;
                        case "5":
                            GIS_CrossingData.intTCD2_Channel = SHD_tblLocations_GIS_WS.TCD2_ChannelType.None;
                            break;
                        default:
                            GIS_CrossingData.intTCD2_Channel = null;
                            break;
                    }

                    GIS_CrossingData.intTCD2_Exempt = ToYesNo(Xing.HD.EXEMPT.ToString());
                    GIS_CrossingData.intTCD2_EnsSign = ToYesNo(Xing.HD.ENSSIGN.ToString());
                    GIS_CrossingData.strTCD2_OthDes1 = Xing.HD.OTHDES1;
                    GIS_CrossingData.intTCD2_OthSgn1 = ToIntNull(Xing.HD.OTHSGN1);
                    GIS_CrossingData.strTCD2_OthDes2 = Xing.HD.OTHDES2;
                    GIS_CrossingData.intTCD2_OthSgn2 = ToIntNull(Xing.HD.OTHSGN2);
                    GIS_CrossingData.strTCD2_OthDes3 = Xing.HD.OTHDES3;
                    GIS_CrossingData.intTCD2_OthSgn3 = ToIntNull(Xing.HD.OTHSGN3);
                    GIS_CrossingData.intTCD2_PrvxSign = ToYesNo(Xing.HD.PRVXSIGN.ToString());
                    GIS_CrossingData.strTCD2_Led = Xing.HD.LED;

                    // Active Traffic Control Device field assignments:
                    GIS_CrossingData.intTCD2_Gates = ToIntNull(Xing.HD.GATES);
                    GIS_CrossingData.intTCD2_GatePed = ToIntNull(Xing.HD.GATEPED);

                    switch (Xing.HD.GATECONF)
                    {
                        case "1":
                            GIS_CrossingData.intTCD2_GateConf = SHD_tblLocations_GIS_WS.TCD2_GateConfType.Item2Quad;
                            break;
                        case "2":
                            GIS_CrossingData.intTCD2_GateConf = SHD_tblLocations_GIS_WS.TCD2_GateConfType.Item3Quad;
                            break;
                        case "3":
                            GIS_CrossingData.intTCD2_GateConf = SHD_tblLocations_GIS_WS.TCD2_GateConfType.Item4Quad;
                            break;
                        default:
                            GIS_CrossingData.intTCD2_GateConf = null;
                            break;
                    }

                    if (Xing.HD.GATECONFTYPE.Contains("4")) GIS_CrossingData.intTCD2_GateConfType_Full = 0; else GIS_CrossingData.intTCD2_GateConfType_Full = null;
                    if (Xing.HD.GATECONFTYPE.Contains("6")) GIS_CrossingData.intTCD2_GateConfType_Median = 0; else GIS_CrossingData.intTCD2_GateConfType_Median = null;

                    GIS_CrossingData.intTCD2_FlashOv = ToIntNull(Xing.HD.FLASHOV.ToString());
                    GIS_CrossingData.intTCD2_FlashNov = ToIntNull(Xing.HD.FLASHNOV.ToString());

                    if (Xing.HD.CFLASHTYPE.Contains("1")) GIS_CrossingData.intTCD2_CFlashType_Incandescent = 0; else GIS_CrossingData.intTCD2_CFlashType_Incandescent = null;
                    if (Xing.HD.CFLASHTYPE.Contains("2")) GIS_CrossingData.intTCD2_CFlashType_LED = 0; else GIS_CrossingData.intTCD2_CFlashType_LED = null;

                    GIS_CrossingData.intTCD2_FlashPost = ToIntNull(Xing.HD.FLASHPOST.ToString());

                    if (Xing.HD.FLASHPOSTTYPE.Contains("1")) GIS_CrossingData.intTCD2_FlashPostType_Incandescent = 0; else GIS_CrossingData.intTCD2_FlashPostType_Incandescent = null;
                    if (Xing.HD.FLASHPOSTTYPE.Contains("2")) GIS_CrossingData.intTCD2_FlashPostType_LED = 0; else GIS_CrossingData.intTCD2_FlashPostType_LED = null;
                    if (Xing.HD.BKL_FLASHPOST.ToString() == "1") GIS_CrossingData.intTCD2_Bkl_FlashPost = 0; else GIS_CrossingData.intTCD2_Bkl_FlashPost = null;
                    if (Xing.HD.SDL_FLASHPOST.ToString() == "1") GIS_CrossingData.intTCD2_Sdl_FlashPost = 0; else GIS_CrossingData.intTCD2_Sdl_FlashPost = null;

                    GIS_CrossingData.intTCD2_FlashPai = ToIntNull(Xing.HD.FLASHPAI.ToString());

                    switch (Xing.HD.AWDIDATE)
                    {
                        case "":
                            GIS_CrossingData.strTCD2_AwdIDate = null;
                            break;
                        case "-1":
                            GIS_CrossingData.strTCD2_AwdIDate = null;
                            break;
                        default:
                            GIS_CrossingData.strTCD2_AwdIDate = Xing.HD.AWDIDATE.Insert(2, "/");
                            break;
                    }

                    if (Xing.HD.AWDIDATE == "-1") GIS_CrossingData.intTCD2_AwdIDate_NotRequired = SHD_tblLocations_GIS_WS.TCD2_AwdIDate_NotRequiredType.NotRequired; else GIS_CrossingData.intTCD2_AwdIDate_NotRequired = null;
                    if (Xing.HD.AWHORNLDATE == "") GIS_CrossingData.strTCD2_AwhornlDate = null; else GIS_CrossingData.strTCD2_AwhornlDate = Xing.HD.AWHORNLDATE.Insert(2, "/");

                    GIS_CrossingData.intTCD2_AwhornChk = ToYesNo(Xing.HD.AWHORNCHK.ToString());
                    GIS_CrossingData.intTCD2_HwyTrafSignl = ToYesNo(Xing.HD.HWYTRAFSIGNL.ToString());
                    GIS_CrossingData.intTCD2_Bells = ToIntNull(Xing.HD.BELLS.ToString());

                    switch (Xing.HD.SPECPRO)
                    {
                        case "0":
                            GIS_CrossingData.intTCD2_SpecPro = SHD_tblLocations_GIS_WS.TCD2_SpecProType.None;
                            break;
                        case "1":
                            GIS_CrossingData.intTCD2_SpecPro = SHD_tblLocations_GIS_WS.TCD2_SpecProType.FlaggingFlagman;
                            break;
                        case "2":
                            GIS_CrossingData.intTCD2_SpecPro = SHD_tblLocations_GIS_WS.TCD2_SpecProType.ManuallyOperatedSignals;
                            break;
                        case "3":
                            GIS_CrossingData.intTCD2_SpecPro = SHD_tblLocations_GIS_WS.TCD2_SpecProType.Watchman;
                            break;
                        case "4":
                            GIS_CrossingData.intTCD2_SpecPro = SHD_tblLocations_GIS_WS.TCD2_SpecProType.Floodlighting;
                            break;
                        default:
                            GIS_CrossingData.intTCD2_SpecPro = null;
                            break;
                    }

                    GIS_CrossingData.intTCD2_FlashOth = ToIntNull(Xing.HD.FLASHOTH.ToString());
                    GIS_CrossingData.strTCD2_FlashOthDes = Xing.HD.FLASHOTHDES;
                    GIS_CrossingData.intTCD2_HwynrSig = ToYesNo(Xing.HD.HWYNRSIG.ToString());

                    if (Xing.HD.INTRPRMP.Contains("1")) GIS_CrossingData.intTCD2_Intrprmp_NotInterConnected = 0; else GIS_CrossingData.intTCD2_Intrprmp_NotInterConnected = null;
                    if (Xing.HD.INTRPRMP.Contains("2")) GIS_CrossingData.intTCD2_Intrprmp_ForTrafficSignals = 0; else GIS_CrossingData.intTCD2_Intrprmp_ForTrafficSignals = null;
                    if (Xing.HD.INTRPRMP.Contains("3")) GIS_CrossingData.intTCD2_Intrprmp_ForWarningSigns = 0; else GIS_CrossingData.intTCD2_Intrprmp_ForWarningSigns = null;

                    switch (Xing.HD.PREMPTYPE.ToString())
                    {
                        case "1":
                            GIS_CrossingData.intTCD2_PrempType = SHD_tblLocations_GIS_WS.TCD2_PrempTypeType.Simultaneous;
                            break;
                        case "2":
                            GIS_CrossingData.intTCD2_PrempType = SHD_tblLocations_GIS_WS.TCD2_PrempTypeType.Advance;
                            break;
                        default:
                            GIS_CrossingData.intTCD2_PrempType = null;
                            break;
                    }

                    GIS_CrossingData.intTCD2_HwtrfPsig = ToYesNo(Xing.HD.HWTRFPSIG.ToString());
                    GIS_CrossingData.intTCD2_HwtrfPsigsdis = ToIntNull(Xing.HD.HWTRFPSIGSDIS);
                    GIS_CrossingData.intTCD2_HwtrfPsiglndis = ToIntNull(Xing.HD.HWTRFPSIGLNDIS);

                    if (Xing.HD.MONITORDEV.Contains("1")) GIS_CrossingData.intTCD2_MonitorDev_Photo = 0; else GIS_CrossingData.intTCD2_MonitorDev_Photo = null;
                    if (Xing.HD.MONITORDEV.Contains("2")) GIS_CrossingData.intTCD2_MonitorDev_VPD = 0; else GIS_CrossingData.intTCD2_MonitorDev_VPD = null;
                    if (Xing.HD.MONITORDEV.Contains("0")) GIS_CrossingData.intTCD2_MonitorDev_None = 0; else GIS_CrossingData.intTCD2_MonitorDev_None = null;

                    // Assign Location Type using TCD data
                    GIS_CrossingData.strLocationType = LocationType();
                    GIS_CrossingData.strCalculatedLocationType = LocationType();
                }

                // Lookup Region by DivCode using Remedy Division form
                using (Division_GIS_WS.Division_GISPortTypeClient client = new Division_GIS_WS.Division_GISPortTypeClient("Division_GISSoap"))
                {
                    _logger.Info("   DivCode: " + GIS_CrossingData.strDivCode);

                    GIS_CrossingData.strRegion = client.GetRegion(new Division_GIS_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    GIS_CrossingData.strDivCode);
                }

                strResult = "";
            }
            catch (Exception err)
            {
                _logger.Error(err, "GIS_CrossingRead() Fatal Error.");

                // If failure occurs when looking up Division by Number, give the end-user a clearer error message:
                if (err.Message.ToString() == "ERROR (302): Entry does not exist in database; For qualification:'536871035' = $NULL$")
                    strErrMessage = "Division Number not found on file";
                else
                    strErrMessage = err.Message.ToString();

                NotifyCrossingErrorOccurred(strChangedDOT, strErrMessage);
                strResult = "Failure";
                // No need to throw; we want the calling process to continue.
            }

            return strResult;
        }

        private String CreateCrossing(String strChangedDOT)
        {
            // Call Remedy web-service to create record in SHD_tblLocations form for passed DOT.
            // Pass all values for record from global GIS Crossing Data object.
            String strResult;

            try
            {
                _logger.Info("  Creating: " + strChangedDOT + " (" + intRefreshPointer.ToString() + ")");

                // Create Remedy Crossing with GIS Crossing data
                using (SHD_tblLocations_GIS_WS.GISPortTypeClient client = new SHD_tblLocations_GIS_WS.GISPortTypeClient("GISSoap"))
                {
                    strResult = client.CreateCrossing(new SHD_tblLocations_GIS_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strChangedDOT,
                    GIS_CrossingData.strCity,
                    GIS_CrossingData.strDivision,
                    GIS_CrossingData.strLineID,
                    GIS_CrossingData.strLocationCategory,
                    GIS_CrossingData.strLocationType,
                    GIS_CrossingData.strCalculatedLocationType,
                    GIS_CrossingData.strMP,
                    GIS_CrossingData.strOperationsDivision,
                    GIS_CrossingData.intPriority,
                    GIS_CrossingData.strRegion,
                    GIS_CrossingData.strShort_Description,
                    GIS_CrossingData.strSiteName,
                    GIS_CrossingData.strState,
                    GIS_CrossingData.intStatus,
                    GIS_CrossingData.strTerritoryCode,
                    GIS_CrossingData.strStreet,
                    GIS_CrossingData.strPrefix,
                    GIS_CrossingData.strSuffix,
                    GIS_CrossingData.strCounty,
                    GIS_CrossingData.strBranch,
                    GIS_CrossingData.strCrossing_District,
                    GIS_CrossingData.strCity_Limits,
                    GIS_CrossingData.strRoute_No,
                    GIS_CrossingData.strRailroad_Code,
                    GIS_CrossingData.strLatitude,
                    GIS_CrossingData.strLongitude,
                    GIS_CrossingData.strCenterLineCrossingLatitude,
                    GIS_CrossingData.strCenterLineCrossingLongitude,
                    GIS_CrossingData.intCrossing_Position_Code,
                    GIS_CrossingData.intCrossing_Type_Code,
                    GIS_CrossingData.strBlock_Number,
                    GIS_CrossingData.strQuiet_Zone,
                    GIS_CrossingData.strSite_Phone,
                    GIS_CrossingData.strState_Contact_Phone,
                    GIS_CrossingData.strEmergency_Notification_Phone,
                    GIS_CrossingData.strStation,
                    GIS_CrossingData.intPrivate_Crossing_Code,
                    GIS_CrossingData.strLineSegment,
                    GIS_CrossingData.intCrossing_Purpose_Code,
                    GIS_CrossingData.strCrossing_Owner,
                    GIS_CrossingData.intPublic_Access_Code,
                    GIS_CrossingData.intMainTrk,
                    GIS_CrossingData.intSidingTrk,
                    GIS_CrossingData.intYardTrk,
                    GIS_CrossingData.intTransitTrk,
                    GIS_CrossingData.intIndustryTrk,
                    GIS_CrossingData.strParent_RR,
                    GIS_CrossingData.dtmPostmarkDate,
                    GIS_CrossingData.intReasonID,
                    GIS_CrossingData.Quiet_Zone_Date_Established,
                    GIS_CrossingData.intSepInd,
                    GIS_CrossingData.strSepRr1,
                    GIS_CrossingData.strSepRr2,
                    GIS_CrossingData.intSameInd,
                    GIS_CrossingData.strSameRr1,
                    GIS_CrossingData.strSameRr2,
                    GIS_CrossingData.intTCD2_NoSigns,
                    GIS_CrossingData.intTCD2_XBuck,
                    GIS_CrossingData.intTCD2_StopStd,
                    GIS_CrossingData.intTCD2_YieldStd,
                    GIS_CrossingData.intTCD2_AdvW10_1,
                    GIS_CrossingData.intTCD2_AdvW10_2,
                    GIS_CrossingData.intTCD2_AdvW10_3,
                    GIS_CrossingData.intTCD2_AdvW10_4,
                    GIS_CrossingData.intTCD2_AdvW10_11,
                    GIS_CrossingData.intTCD2_AdvW10_12,
                    GIS_CrossingData.intTCD2_Low_GrndSigns,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_Stop_Lines,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_RR_Xing_Symbols,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_Dynamic_Envelope,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_None,
                    GIS_CrossingData.intTCD2_Channel,
                    GIS_CrossingData.intTCD2_Exempt,
                    GIS_CrossingData.intTCD2_EnsSign,
                    GIS_CrossingData.strTCD2_OthDes1,
                    GIS_CrossingData.intTCD2_OthSgn1,
                    GIS_CrossingData.strTCD2_OthDes2,
                    GIS_CrossingData.intTCD2_OthSgn2,
                    GIS_CrossingData.strTCD2_OthDes3,
                    GIS_CrossingData.intTCD2_OthSgn3,
                    GIS_CrossingData.intTCD2_PrvxSign,
                    GIS_CrossingData.strTCD2_Led,
                    GIS_CrossingData.intTCD2_Gates,
                    GIS_CrossingData.intTCD2_GatePed,
                    GIS_CrossingData.intTCD2_GateConf,
                    GIS_CrossingData.intTCD2_GateConfType_Full,
                    GIS_CrossingData.intTCD2_GateConfType_Median,
                    GIS_CrossingData.intTCD2_FlashOv,
                    GIS_CrossingData.intTCD2_FlashNov,
                    GIS_CrossingData.intTCD2_CFlashType_Incandescent,
                    GIS_CrossingData.intTCD2_CFlashType_LED,
                    GIS_CrossingData.intTCD2_FlashPost,
                    GIS_CrossingData.intTCD2_FlashPostType_Incandescent,
                    GIS_CrossingData.intTCD2_FlashPostType_LED,
                    GIS_CrossingData.intTCD2_Bkl_FlashPost,
                    GIS_CrossingData.intTCD2_Sdl_FlashPost,
                    GIS_CrossingData.intTCD2_FlashPai,
                    GIS_CrossingData.strTCD2_AwdIDate,
                    GIS_CrossingData.intTCD2_AwdIDate_NotRequired,
                    GIS_CrossingData.strTCD2_AwhornlDate,
                    GIS_CrossingData.intTCD2_AwhornChk,
                    GIS_CrossingData.intTCD2_HwyTrafSignl,
                    GIS_CrossingData.intTCD2_Bells,
                    GIS_CrossingData.intTCD2_SpecPro,
                    GIS_CrossingData.intTCD2_FlashOth,
                    GIS_CrossingData.strTCD2_FlashOthDes,
                    GIS_CrossingData.intTCD2_HwynrSig,
                    GIS_CrossingData.intTCD2_Intrprmp_NotInterConnected,
                    GIS_CrossingData.intTCD2_Intrprmp_ForTrafficSignals,
                    GIS_CrossingData.intTCD2_Intrprmp_ForWarningSigns,
                    GIS_CrossingData.intTCD2_PrempType,
                    GIS_CrossingData.intTCD2_HwtrfPsig,
                    GIS_CrossingData.intTCD2_HwtrfPsigsdis,
                    GIS_CrossingData.intTCD2_HwtrfPsiglndis,
                    GIS_CrossingData.intTCD2_MonitorDev_Photo,
                    GIS_CrossingData.intTCD2_MonitorDev_VPD,
                    GIS_CrossingData.intTCD2_MonitorDev_None);

                    strResult = "";     // Success
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "CreateCrossing() Fatal Error.");
                NotifyCrossingErrorOccurred(strChangedDOT, err.Message);
                strResult = "Failure";
                // No need to throw; we want the calling process to continue.
            }

            return strResult;
        }

        private String UpdateCrossingByDOT(String strChangedDOT)
        {
            // Call Remedy web-service to update record in SHD_tblLocations form for passed DOT.
            // Pass all values for record from global GIS Crossing Data object.
            String strResult;

            try
            {
                _logger.Info("  Updating: " + strChangedDOT + " (" + intRefreshPointer.ToString() + ")");

                // Update Remedy Crossing with GIS Crossing data
                using (SHD_tblLocations_GIS_WS.GISPortTypeClient client = new SHD_tblLocations_GIS_WS.GISPortTypeClient("GISSoap"))
                {   // The following fields are not passed since they are only populated during the initial CreateCrossing operation.
                    // The user is allowed to modify these fields in Remedy; we don't want their changes overwritten by the GIS feed.
                    // SiteName
                    // Priority
                    // Operations Division
                    // TeritoryCode
                    // Equipment Latitude
                    // Equipment Longitude
                    // Status
                    // LocationType

                    strResult = client.UpdateCrossingByDOT(new SHD_tblLocations_GIS_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    strChangedDOT,
                    GIS_CrossingData.strCity,
                    GIS_CrossingData.strDivision,
                    GIS_CrossingData.strLineID,
                    GIS_CrossingData.strLocationCategory,
                    GIS_CrossingData.strCalculatedLocationType,
                    GIS_CrossingData.strMP,
                    GIS_CrossingData.strRegion,
                    GIS_CrossingData.strShort_Description,
                    GIS_CrossingData.strState,
                    GIS_CrossingData.strStreet,
                    GIS_CrossingData.strPrefix,
                    GIS_CrossingData.strSuffix,
                    GIS_CrossingData.strCounty,
                    GIS_CrossingData.strBranch,
                    GIS_CrossingData.strCrossing_District,
                    GIS_CrossingData.strCity_Limits,
                    GIS_CrossingData.strRoute_No,
                    GIS_CrossingData.strRailroad_Code,
                    GIS_CrossingData.strCenterLineCrossingLatitude,
                    GIS_CrossingData.strCenterLineCrossingLongitude,
                    GIS_CrossingData.intCrossing_Position_Code,
                    GIS_CrossingData.intCrossing_Type_Code,
                    GIS_CrossingData.strBlock_Number,
                    GIS_CrossingData.strQuiet_Zone,
                    GIS_CrossingData.strSite_Phone,
                    GIS_CrossingData.strState_Contact_Phone,
                    GIS_CrossingData.strEmergency_Notification_Phone,
                    GIS_CrossingData.strStation,
                    GIS_CrossingData.intPrivate_Crossing_Code,
                    GIS_CrossingData.strLineSegment,
                    GIS_CrossingData.intCrossing_Purpose_Code,
                    GIS_CrossingData.strCrossing_Owner,
                    GIS_CrossingData.intPublic_Access_Code,
                    GIS_CrossingData.intMainTrk,
                    GIS_CrossingData.intSidingTrk,
                    GIS_CrossingData.intYardTrk,
                    GIS_CrossingData.intTransitTrk,
                    GIS_CrossingData.intIndustryTrk,
                    GIS_CrossingData.strParent_RR,
                    GIS_CrossingData.dtmPostmarkDate,
                    GIS_CrossingData.intReasonID,
                    GIS_CrossingData.Quiet_Zone_Date_Established,
                    GIS_CrossingData.intSepInd,
                    GIS_CrossingData.strSepRr1,
                    GIS_CrossingData.strSepRr2,
                    GIS_CrossingData.intSameInd,
                    GIS_CrossingData.strSameRr1,
                    GIS_CrossingData.strSameRr2,
                    GIS_CrossingData.intTCD2_NoSigns,
                    GIS_CrossingData.intTCD2_XBuck,
                    GIS_CrossingData.intTCD2_StopStd,
                    GIS_CrossingData.intTCD2_YieldStd,
                    GIS_CrossingData.intTCD2_AdvW10_1,
                    GIS_CrossingData.intTCD2_AdvW10_2,
                    GIS_CrossingData.intTCD2_AdvW10_3,
                    GIS_CrossingData.intTCD2_AdvW10_4,
                    GIS_CrossingData.intTCD2_AdvW10_11,
                    GIS_CrossingData.intTCD2_AdvW10_12,
                    GIS_CrossingData.intTCD2_Low_GrndSigns,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_Stop_Lines,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_RR_Xing_Symbols,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_Dynamic_Envelope,
                    GIS_CrossingData.intTCD2_PaveMrkIDs_None,
                    GIS_CrossingData.intTCD2_Channel,
                    GIS_CrossingData.intTCD2_Exempt,
                    GIS_CrossingData.intTCD2_EnsSign,
                    GIS_CrossingData.strTCD2_OthDes1,
                    GIS_CrossingData.intTCD2_OthSgn1,
                    GIS_CrossingData.strTCD2_OthDes2,
                    GIS_CrossingData.intTCD2_OthSgn2,
                    GIS_CrossingData.strTCD2_OthDes3,
                    GIS_CrossingData.intTCD2_OthSgn3,
                    GIS_CrossingData.intTCD2_PrvxSign,
                    GIS_CrossingData.strTCD2_Led,
                    GIS_CrossingData.intTCD2_Gates,
                    GIS_CrossingData.intTCD2_GatePed,
                    GIS_CrossingData.intTCD2_GateConf,
                    GIS_CrossingData.intTCD2_GateConfType_Full,
                    GIS_CrossingData.intTCD2_GateConfType_Median,
                    GIS_CrossingData.intTCD2_FlashOv,
                    GIS_CrossingData.intTCD2_FlashNov,
                    GIS_CrossingData.intTCD2_CFlashType_Incandescent,
                    GIS_CrossingData.intTCD2_CFlashType_LED,
                    GIS_CrossingData.intTCD2_FlashPost,
                    GIS_CrossingData.intTCD2_FlashPostType_Incandescent,
                    GIS_CrossingData.intTCD2_FlashPostType_LED,
                    GIS_CrossingData.intTCD2_Bkl_FlashPost,
                    GIS_CrossingData.intTCD2_Sdl_FlashPost,
                    GIS_CrossingData.intTCD2_FlashPai,
                    GIS_CrossingData.strTCD2_AwdIDate,
                    GIS_CrossingData.intTCD2_AwdIDate_NotRequired,
                    GIS_CrossingData.strTCD2_AwhornlDate,
                    GIS_CrossingData.intTCD2_AwhornChk,
                    GIS_CrossingData.intTCD2_HwyTrafSignl,
                    GIS_CrossingData.intTCD2_Bells,
                    GIS_CrossingData.intTCD2_SpecPro,
                    GIS_CrossingData.intTCD2_FlashOth,
                    GIS_CrossingData.strTCD2_FlashOthDes,
                    GIS_CrossingData.intTCD2_HwynrSig,
                    GIS_CrossingData.intTCD2_Intrprmp_NotInterConnected,
                    GIS_CrossingData.intTCD2_Intrprmp_ForTrafficSignals,
                    GIS_CrossingData.intTCD2_Intrprmp_ForWarningSigns,
                    GIS_CrossingData.intTCD2_PrempType,
                    GIS_CrossingData.intTCD2_HwtrfPsig,
                    GIS_CrossingData.intTCD2_HwtrfPsigsdis,
                    GIS_CrossingData.intTCD2_HwtrfPsiglndis,
                    GIS_CrossingData.intTCD2_MonitorDev_Photo,
                    GIS_CrossingData.intTCD2_MonitorDev_VPD,
                    GIS_CrossingData.intTCD2_MonitorDev_None);

                    strResult = "";     // Success
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "UpdateCrossingByDOT() Fatal Error.");
                NotifyCrossingErrorOccurred(strChangedDOT, err.Message);
                strResult = "Failure";
                // No need to throw; we want the calling process to continue.
            }

            return strResult;
        }

        private String UpdateLastRefreshed(DateTime dtmNow)
        {
            // Update Remedy SHD_tblLocations_GIS_Refresh form with passed Last Refresh Date/Time value.
            String strResult;

            try
            {
                using (SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient client = new SHD_tblLocations_GIS_Refresh_WS.GIS_RefreshPortTypeClient("GIS_RefreshSoap"))
                {
                    strResult = client.UpdateLastRefreshed(new SHD_tblLocations_GIS_Refresh_WS.AuthenticationInfo()
                    {
                        userName = Config.RemedyUser,
                        password = Config.RemedyPwdr
                    },
                    "000000000000001",
                    dtmNow,
                    "N/A");
                }
            }
            catch (Exception err)
            {
                _logger.Error(err, "UpdateLastRefreshed() Fatal Error.");
                strResult = "Failure";
                throw;
            }

            return strResult;
        }
    }
}
