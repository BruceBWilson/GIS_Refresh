﻿using AppShared;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSCorp.GIS_Refresh
{
    public class EnListSchedule : CrossAppDomainObject, IScheduledJob
    {
        private Logger _logger = LogManager.GetCurrentClassLogger();
        private GIS_CrossingRefresh gcr = new GIS_CrossingRefresh();

        public string CronSchedule
        {
            get
            {
                return Config.CronSchedule_Minute;  // Use for Testing
//              return Config.CronSchedule_Hourly;  // Use for Production
            }
        }

        public string Description
        {
            get
            {
                return $"Last Run at {DateTime.Now.ToUniversalTime()}";
            }
        }

        public string Name
        {
            get
            {
                return "Job used to refresh signal locations from GIS";
            }
        }

        public ScheduledJobStatus Status { get; set; }

        public void Execute()
        {
            _logger.Debug("Entering GIS Job");

            try
            {
                if (gcr.IAmRunning == false)
                {
                    var result = gcr.Refresh();
                    _logger.Debug($"GIS Job Resolved {result}");
                }
                else
                {
                    _logger.Debug("GIS Job Already Executing");
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Exception occured in GIS Job");
            }

            _logger.Debug("Exiting GIS Job");
        }
    }
}
