﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSCorp.GIS_Refresh
{
    static public class Config
    {
        static public String RemedyUser { get { return Helper.GetAppSetting("remedy:userid"); } }
        static public String RemedyPwdr { get { return Helper.GetAppSetting("remedy:password"); } }

        static public String CronSchedule_Minute { get { return Helper.GetAppSetting("CronSchedule_Minute"); } }
        static public String CronSchedule_Hourly { get { return Helper.GetAppSetting("CronSchedule_Hourly"); } }
    }

    static public class Helper
    {
        static public Int32 GetAppSettingInt(String config)
        {
            Int32 intFound = 0;
            if (ConfigurationManager.AppSettings[config] != null)
            {
                if (!Int32.TryParse(ConfigurationManager.AppSettings[config].ToString(), out intFound)) intFound = 0;
            }
            return intFound;
        }

        static public Boolean GetAppSettingBoolean(String config)
        {

            if (ConfigurationManager.AppSettings[config] != null)
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings[config].ToString());
            }
            else
            {
                return false;
            }
        }

        static public String GetAppSetting(String config)
        {

            if (ConfigurationManager.AppSettings[config] != null)
            {
                return ConfigurationManager.AppSettings[config].ToString();
            }
            else
            {
                return "";
            }
        }
    }
}