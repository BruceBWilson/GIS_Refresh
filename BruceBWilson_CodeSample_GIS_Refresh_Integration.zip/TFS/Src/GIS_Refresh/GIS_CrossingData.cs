﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSCorp.GIS_Refresh
{
    class GIS_CrossingData
    {
        // Required fields
        public String strCity { get; set; }
        public String strDivision { get; set; }
        public String strDivCode { get; set; }
        public String strLineID { get; set; }
        public String strLocationCategory { get; set; }
        public String strLocationType { get; set; }
        public String strMP { get; set; }
        public String strOperationsDivision { get; set; }
        public SHD_tblLocations_GIS_WS.PriorityType intPriority { get; set; }
        public String strRegion { get; set; }
        public String strShort_Description { get; set; }
        public String strSiteName { get; set; }
        public String strState { get; set; }
        public SHD_tblLocations_GIS_WS.StatusType intStatus { get; set; }
        public String strTerritoryCode { get; set; }

        // Optional fields
        public String strCalculatedLocationType { get; set; }
        public String strStreet { get; set; }
        public String strPrefix { get; set; }
        public String strSuffix { get; set; }
        public String strCounty { get; set; }
        public String strBranch { get; set; }
        public String strCrossing_District { get; set; }
        public String strCity_Limits { get; set; }
        public String strRoute_No { get; set; }
        public String strRailroad_Code { get; set; }
        public String strLatitude { get; set; }
        public String strLongitude { get; set; }
        public String strCenterLineCrossingLatitude { get; set; }
        public String strCenterLineCrossingLongitude { get; set; }
        public SHD_tblLocations_GIS_WS.Crossing_Position_CodeType? intCrossing_Position_Code { get; set; }
        public SHD_tblLocations_GIS_WS.Crossing_Type_CodeType? intCrossing_Type_Code { get; set; }
        public String strBlock_Number { get; set; }
        public String strQuiet_Zone { get; set; }
        public String strSite_Phone { get; set; }
        public String strState_Contact_Phone { get; set; }
        public String strEmergency_Notification_Phone { get; set; }
        public String strStation { get; set; }
        public SHD_tblLocations_GIS_WS.Private_Crossing_CodeType? intPrivate_Crossing_Code { get; set; }
        public String strLineSegment { get; set; }
        public SHD_tblLocations_GIS_WS.Crossing_Purpose_CodeType? intCrossing_Purpose_Code { get; set; }
        public String strCrossing_Owner { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intPublic_Access_Code { get; set; }
        public int? intMainTrk { get; set; }
        public int? intSidingTrk { get; set; }
        public int? intYardTrk { get; set; }
        public int? intTransitTrk { get; set; }
        public int? intIndustryTrk { get; set; }
        public String strParent_RR { get; set; }
        public DateTime? dtmPostmarkDate { get; set; }
        public SHD_tblLocations_GIS_WS.ReasonIDType? intReasonID { get; set; }
        public DateTime? Quiet_Zone_Date_Established { get; set; }

        // Foreign Railroad fields
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intSepInd { get; set; }
        public String strSepRr1 { get; set; }
        public String strSepRr2 { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intSameInd { get; set; }
        public String strSameRr1 { get; set; }
        public String strSameRr2 { get; set; }

        // Passive Traffic Control Device fields
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_NoSigns { get; set; }
        public int? intTCD2_XBuck { get; set; }
        public int? intTCD2_StopStd { get; set; }
        public int? intTCD2_YieldStd { get; set; }
        public int? intTCD2_AdvW10_1 { get; set; }
        public int? intTCD2_AdvW10_2 { get; set; }
        public int? intTCD2_AdvW10_3 { get; set; }
        public int? intTCD2_AdvW10_4 { get; set; }
        public int? intTCD2_AdvW10_11 { get; set; }
        public int? intTCD2_AdvW10_12 { get; set; }
        public int? intTCD2_Low_GrndSigns { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PaveMrkIDs_Stop_LinesType? intTCD2_PaveMrkIDs_Stop_Lines { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PaveMrkIDs_RR_Xing_SymbolsType? intTCD2_PaveMrkIDs_RR_Xing_Symbols { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PaveMrkIDs_Dynamic_EnvelopeType? intTCD2_PaveMrkIDs_Dynamic_Envelope { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PaveMrkIDs_NoneType? intTCD2_PaveMrkIDs_None { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_ChannelType? intTCD2_Channel { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_Exempt { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_EnsSign { get; set; }
        public String strTCD2_OthDes1 { get; set; }
        public int? intTCD2_OthSgn1 { get; set; }
        public String strTCD2_OthDes2 { get; set; }
        public int? intTCD2_OthSgn2 { get; set; }
        public String strTCD2_OthDes3 { get; set; }
        public int? intTCD2_OthSgn3 { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_PrvxSign { get; set; }
        public String strTCD2_Led { get; set; }

        // Active Traffic Control Device fields
        public int? intTCD2_Gates { get; set; }
        public int? intTCD2_GatePed { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_GateConfType? intTCD2_GateConf { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_GateConfType_FullType? intTCD2_GateConfType_Full { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_GateConfType_MedianType? intTCD2_GateConfType_Median { get; set; }
        public int? intTCD2_FlashOv { get; set; }
        public int? intTCD2_FlashNov { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_CFlashType_IncandescentType? intTCD2_CFlashType_Incandescent { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_CFlashType_LEDType? intTCD2_CFlashType_LED { get; set; }
        public int? intTCD2_FlashPost { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_CFlashType_IncandescentType? intTCD2_FlashPostType_Incandescent { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_CFlashType_LEDType? intTCD2_FlashPostType_LED { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_Bkl_FlashPostType? intTCD2_Bkl_FlashPost { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_Sdl_FlashPostType? intTCD2_Sdl_FlashPost { get; set; }
        public int? intTCD2_FlashPai { get; set; }
        public String strTCD2_AwdIDate { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_AwdIDate_NotRequiredType? intTCD2_AwdIDate_NotRequired { get; set; }
        public String strTCD2_AwhornlDate { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_AwhornChk { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_HwyTrafSignl { get; set; }
        public int? intTCD2_Bells { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_SpecProType? intTCD2_SpecPro { get; set; }
        public int? intTCD2_FlashOth { get; set; }
        public String strTCD2_FlashOthDes { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_HwynrSig { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_Intrprmp_NotInterConnectedType? intTCD2_Intrprmp_NotInterConnected { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_Intrprmp_ForTrafficSignalsType? intTCD2_Intrprmp_ForTrafficSignals { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_Intrprmp_ForWarningSignsType? intTCD2_Intrprmp_ForWarningSigns { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PrempTypeType? intTCD2_PrempType { get; set; }
        public SHD_tblLocations_GIS_WS.Public_Access_CodeType? intTCD2_HwtrfPsig { get; set; }
        public int? intTCD2_HwtrfPsigsdis { get; set; }
        public int? intTCD2_HwtrfPsiglndis { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_MonitorDev_PhotoType? intTCD2_MonitorDev_Photo { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_MonitorDev_VPDType? intTCD2_MonitorDev_VPD { get; set; }
        public SHD_tblLocations_GIS_WS.TCD2_PaveMrkIDs_NoneType? intTCD2_MonitorDev_None { get; set; }
    }
}
