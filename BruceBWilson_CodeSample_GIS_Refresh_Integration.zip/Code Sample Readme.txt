Bruce B. Wilson
404-542-5552
bwilson@datastreamcons.com

Code Sample
06/25/2018

BruceBWilson_CodeSample_GIS_Refresh_Integration.zip:

Integration Utility written in Visual Studio 2015 c#:
1. Reads FRA Railroad Crossing data using Rest Web-services from NSC (Norfolk Southern Corporation)
   GIS (Geographical Information System) servers.
2. Creates/Updates Remedy ITSM Crossing form records using SOAP Web-services with data from GIS Web-services.
3. Provides logging using NLog Open Source.
4. When data integrity/constraints are violated during Remedy Crossing form record create/update:
	A. Creates Exception errors using Remedy error form.
	B. Reports these errors using individual emails to NSC Crossing Data team.
5. Crossing Errors in Remedy can be flagged using the Remedy UI to be reprocessed the next time the application is run.
6. The application uses Cron Scheduler to run either once a minute (in Development environment) or once an hour (in production environment).
7. When a fatal application processing error occurs the Remedy administrator is sent an email containing the error message.
8. NOTE: No direct connection to the database is done in this utility:
	A. The GIS and Remedy web-services being called will read/update the database accordingly.
